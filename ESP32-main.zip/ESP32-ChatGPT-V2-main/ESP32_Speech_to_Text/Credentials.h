// Provide all the crdentials here



// Your WiFi Credentials 
const char *ssid = "iPhone 11";       // WiFi SSID Name
const char *password = "Xsgd703*";// WiFi Password ( Keep it blank if your WiFi router is open )


// Parameters of Google Speech to Text API
const String ApiKey = "AIzaSyD1uRXzlv-_6k7OuJ5QWSjC8DSKOKtPa5g";// Google Speech to Text API key
String SpeechtoText_Language = "en-IN"; // Language 

// Parameters of OpenAI API 
const char* chatgpt_token = "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"; // OpenAI API Key
String OpenAI_Model = "gpt-3.5-turbo-instruct"; // Model
String OpenAI_Temperature = "0.20"; // temperature
String OpenAI_Max_Tokens = "40"; //Max Tokens 
